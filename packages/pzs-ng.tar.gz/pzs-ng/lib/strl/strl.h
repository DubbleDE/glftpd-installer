#ifndef __STRL_H__
#define __STRL_H__

#include <sys/types.h>

size_t strlcpy(char *, const char *, size_t);

#endif
