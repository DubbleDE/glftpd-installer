#ifndef _NG_VERSION_H_
#define _NG_VERSION_H_

#define NG_VERSION "git-master-2dc803d8"

#endif
